#!/bin/bash

# Actualizar e instalar dependencias necesarias
echo "[+] Actualizando el sistema e instalando dependencias..."

# Actualizar paquetes del sistema
sudo apt update -y

# Instalar paquetes esenciales
sudo apt install -y python3 python3-pip nmap scapy dnsspoof sslstrip arpspoof

# Instalar dependencias de Python
pip3 install flask chart.js

# Verificar si las dependencias se instalaron correctamente
if [ $? -eq 0 ]; then
    echo "[+] Todas las dependencias fueron instaladas correctamente."
else
    echo "[!] Ocurrió un problema durante la instalación de las dependencias."
    exit 1
fi

# Confirmación final
echo "[+] Sistema listo para ejecutar el proyecto MITM."
